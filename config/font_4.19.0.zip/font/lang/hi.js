/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'hi', {
	fontSize: {
		label: 'साइज़',
		voiceLabel: 'Font Size',
		panelTitle: 'साइज़'
	},
	label: 'फ़ॉन्ट',
	panelTitle: 'फ़ॉन्ट',
	voiceLabel: 'फ़ॉन्ट'
} );
