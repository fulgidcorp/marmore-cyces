/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'mn', {
	fontSize: {
		label: 'Хэмжээ',
		voiceLabel: 'Үсгийн хэмжээ',
		panelTitle: 'Үсгийн хэмжээ'
	},
	label: 'Үсгийн хэлбэр',
	panelTitle: 'Үгсийн хэлбэрийн нэр',
	voiceLabel: 'Үгсийн хэлбэр'
} );
